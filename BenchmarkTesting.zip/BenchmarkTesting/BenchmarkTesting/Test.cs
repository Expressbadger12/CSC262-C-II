﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BenchmarkDotNet.Analysers;
using BenchmarkDotNet.Attributes;

namespace BenchmarkTesting
{
    public class Test
    {
        [Benchmark]
        //add strimgs together using + sign
        public string UsingPlusOperator()
        {
            string sResult = "";

            //create a string with 10 characters
            for (int i = 0; i < 1000; i++) 
            {
                //add z to string r ry loop
                sResult += "z";
            }
            return sResult;
        }

        [Benchmark]
        public string UsingSringBuilder() 
        {
            
            //create a string builder
            StringBuilder builder = new StringBuilder();

            for (int i = 0; i < 1000; i++)
            {
                //add z to string r ry loop
                builder.Append("z");
            }
            return builder.ToString();

        }
    }
}
