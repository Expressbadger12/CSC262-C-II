﻿namespace w10badabing
{
    partial class frmsqllite
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dgvPerson = new DataGridView();
            lblID = new Label();
            txtID = new TextBox();
            txtAge = new TextBox();
            lblAge = new Label();
            txtName = new TextBox();
            lblName = new Label();
            btnSave = new Button();
            btnDelete = new Button();
            ((System.ComponentModel.ISupportInitialize)dgvPerson).BeginInit();
            SuspendLayout();
            // 
            // dgvPerson
            // 
            dgvPerson.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dgvPerson.Location = new Point(61, 202);
            dgvPerson.Name = "dgvPerson";
            dgvPerson.RowHeadersWidth = 62;
            dgvPerson.Size = new Size(671, 225);
            dgvPerson.TabIndex = 0;
            dgvPerson.SelectionChanged += dgvPerson_SelectionChanged;
            // 
            // lblID
            // 
            lblID.AutoSize = true;
            lblID.Location = new Point(250, 24);
            lblID.Name = "lblID";
            lblID.Size = new Size(34, 25);
            lblID.TabIndex = 1;
            lblID.Text = "ID:";
            // 
            // txtID
            // 
            txtID.Enabled = false;
            txtID.Location = new Point(325, 21);
            txtID.Name = "txtID";
            txtID.Size = new Size(150, 31);
            txtID.TabIndex = 2;
            // 
            // txtAge
            // 
            txtAge.Location = new Point(325, 94);
            txtAge.Name = "txtAge";
            txtAge.Size = new Size(150, 31);
            txtAge.TabIndex = 4;
            // 
            // lblAge
            // 
            lblAge.AutoSize = true;
            lblAge.Location = new Point(250, 97);
            lblAge.Name = "lblAge";
            lblAge.Size = new Size(44, 25);
            lblAge.TabIndex = 3;
            lblAge.Text = "Age";
            // 
            // txtName
            // 
            txtName.Location = new Point(325, 57);
            txtName.Name = "txtName";
            txtName.Size = new Size(150, 31);
            txtName.TabIndex = 6;
            // 
            // lblName
            // 
            lblName.AutoSize = true;
            lblName.Location = new Point(250, 60);
            lblName.Name = "lblName";
            lblName.Size = new Size(63, 25);
            lblName.TabIndex = 5;
            lblName.Text = "Name:";
            // 
            // btnSave
            // 
            btnSave.Location = new Point(341, 144);
            btnSave.Name = "btnSave";
            btnSave.Size = new Size(112, 34);
            btnSave.TabIndex = 7;
            btnSave.Text = "Save";
            btnSave.UseVisualStyleBackColor = true;
            btnSave.Click += btnSave_Click;
            // 
            // btnDelete
            // 
            btnDelete.Location = new Point(363, 489);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new Size(112, 34);
            btnDelete.TabIndex = 8;
            btnDelete.Text = "Delete";
            btnDelete.UseVisualStyleBackColor = true;
            btnDelete.Click += btnDelete_Click;
            // 
            // frmsqllite
            // 
            AutoScaleDimensions = new SizeF(10F, 25F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 559);
            Controls.Add(btnDelete);
            Controls.Add(btnSave);
            Controls.Add(txtName);
            Controls.Add(lblName);
            Controls.Add(txtAge);
            Controls.Add(lblAge);
            Controls.Add(txtID);
            Controls.Add(lblID);
            Controls.Add(dgvPerson);
            Name = "frmsqllite";
            Text = "frmsqllite";
            Load += frmsqllite_Load;
            ((System.ComponentModel.ISupportInitialize)dgvPerson).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dgvPerson;
        private Label lblID;
        private TextBox txtID;
        private TextBox txtAge;
        private Label lblAge;
        private TextBox txtName;
        private Label lblName;
        private Button btnSave;
        private Button btnDelete;
    }
}
