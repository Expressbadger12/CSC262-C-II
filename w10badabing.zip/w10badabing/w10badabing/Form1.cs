using System.Data;
using System.Data.SQLite;

namespace w10badabing
{
    public partial class frmsqllite : Form
    {
        //name of the database
        private string databaseName = "TestDatabase.db";

        public frmsqllite()
        {
            InitializeComponent();
        }

        // function to create database and table if it doesn't already exist
        private void CreateDatabase()
        {
            //check to see if the database file exists; if the file does not exist, create it
            if (!File.Exists(databaseName))
            {
                //create the sqlite database
                SQLiteConnection.CreateFile(databaseName);
                //just for proof of concept -- remove before moving this function to a utility class (ie database helper)
                MessageBox.Show("Database created!");


                //open a connection to the database and create a new table
                using (SQLiteConnection sqliteconn = new SQLiteConnection($"Data Source={databaseName};Version=3;"))
                {
                    //open a connection to the sqlite database that we just created
                    sqliteconn.Open();

                    //sete up the create table query
                    string createTableQuery = "CREATE TABLE tblPerson(ID INTEGER PRIMARY KEY AUTOINCREMENT, Name TEXT NOT NULL, Age INTEGER);";
               
                    using(SQLiteCommand cmd = new SQLiteCommand(createTableQuery, sqliteconn))
                    {
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Table Created!");
                    }
                }
            }
        }

        private void frmsqllite_Load(object sender, EventArgs e)
        {
            CreateDatabase();

            //InsertData("Sally", 25);
            //InsertData("Bob", 19);
            //InsertData("AJ", 30);

            LoadData();
        }

        private void InsertData(string name, int age)
        {
            using (SQLiteConnection sqliteconn = new SQLiteConnection($"Data Source={databaseName};Version=3;"))
            {
                //open a connection to the sqlite database that we just created
                sqliteconn.Open();
                // this is the SQL statement that will create a new record in our table - this is a parameterized query - best practice to thward  things like sql injection
                string insertDataQuery = "INSERT INTO tblPerson (Name, Age) VALUES (@Name, @Age);";
            
                // set up the parameters -@Name, @Age
                using (SQLiteCommand cmd = new SQLiteCommand(insertDataQuery, sqliteconn))
                {
                    //set the values for the parameters
                    cmd.Parameters.AddWithValue("@Name", name);
                    cmd.Parameters.AddWithValue("@Age", age);

                    // execute non query - when we are not getting rows returned - when its not a SELECT statement.
                    //we use executenonquery for INSERT, UPDATE, and DELETE -whenever we are chaning data in the database
                    // the assumption being that we are not getting rows of data from the database to show on out form
                    cmd.ExecuteNonQuery();
                }
            }
        }

        //this function will load data from the tblPerson into the dgv
        private void LoadData()
        {
            using(SQLiteConnection sqliteconn = new SQLiteConnection($"Data Source={databaseName};Version=3;"))
            {
                //open a connection to the sqlite database that we just created
                sqliteconn.Open();

                //get the rows from the table -- this is okay for testing out a msall amoount of data in a local table.
                //in a larget project/databes you always want to specify the column names instead of using * and you should always use a WHERE clause, so WHERE Name = 'Sally':
                string selectQuery = "SELECT * FROM tblPerson;";

                using (SQLiteCommand cmd = new SQLiteCommand(selectQuery, sqliteconn))
                { 
                    // set up an adapter to make the data be able to work with out datagridview
                    using (SQLiteDataAdapter adapter = new SQLiteDataAdapter(cmd))
                    {
                        DataTable dt = new DataTable();
                        adapter.Fill(dt);

                        //finally load the records returned from our SELECT * query ontp tge dataview in our form 
                        dgvPerson.DataSource = dt;
                    }
                }
            }
        }
    }
}
